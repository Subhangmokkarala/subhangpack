# fitzingout
Pip package learning and this is used to setup a new pc with pip libraries i need
