from subhangpack.subhang import hello
from subhangpack.names import namegen
from subhangpack.info import sysinfo